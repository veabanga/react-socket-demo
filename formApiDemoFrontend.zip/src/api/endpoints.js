export const endpoints =  {
    // for demo forms
    demoform: "/formdemo",
    form2:"/form2",


    // for auth
    login:"/login",
    signup:"/signup"

}
